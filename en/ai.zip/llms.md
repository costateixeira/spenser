# jct.fhir.spenser#1.0.0: Spenser - a developer's companion(en)

## Pages

* [Home](index.md)
* [Firmware](firmware.md)
* [Translations](translationinfo.md)
* [Artifacts Summary](artifacts.md)
* [FHIR](fhir-intro.md)
* [Authors](authors.md)
* [Implementing](implementing.md)
* [3D printable parts](hardware-3ddesign.md)
* [Assembly](assembly.md)
* [Usage](usage.md)
* [Downloads](downloads.md)
* [Setup](setup.md)
* [Hardware Bill of Materials](hardware-bom.md)
* [Interfaces](interfaces.md)

## Resources

### CodeSystems

* [Spenser Medications - Code System](CodeSystem-SpenserMeds.md)

### ValueSets

* [Spenser Medications - ValueSet](ValueSet-SpenserMedsVS.md)

### Resource Profiles

* [SpenserRequest](StructureDefinition-SpenserRequest.md)

### Extensions

* [Dispensing device](StructureDefinition-dispensingDevice.md)

### ActorDefinitions

* [Order Placer](ActorDefinition-OrderPlacer.md)
* [Order Server](ActorDefinition-OrderServer.md)
* [Spenser Unit](ActorDefinition-SpenserUnit.md)
* [Unit Owner](ActorDefinition-UnitOwner.md)
* [Update Publisher](ActorDefinition-UpdatePublisher.md)

### CapabilityStatements

* [SpenserFHIRCapabilityStatement](CapabilityStatement-SpenserFHIRCapabilityStatement.md)

### ExampleScenarios

* [Ordering straight from the unit](ExampleScenario-DirectOrderScenario.md)
* [Ordering through an order server](ExampleScenario-TaskOrderScenario.md)

### ImplementationGuides

* [Spenser - a developer's companion](ImplementationGuide-jct.fhir.spenser.md)

### Examples

* [Spenser-E3D4 (Device)](Device-Spenser-E3D4.md)
* [Add5Milk (InventoryReport)](InventoryReport-Add5Milk.md)
* [SetDarkTo17 (InventoryReport)](InventoryReport-SetDarkTo17.md)
* [DeclinedDispenseOutOfStock (MedicationDispense)](MedicationDispense-DeclinedDispenseOutOfStock.md)
* [DispenseForActionableDarkOrder (MedicationDispense)](MedicationDispense-DispenseForActionableDarkOrder.md)
* [DispenseForDirectOrder (MedicationDispense)](MedicationDispense-DispenseForDirectOrder.md)
* [DispenseForTaskOrder (MedicationDispense)](MedicationDispense-DispenseForTaskOrder.md)
* [ActionableDarkOrder (MedicationRequest)](MedicationRequest-ActionableDarkOrder.md)
* [ActionableDarkOrderForOneUnit (MedicationRequest)](MedicationRequest-ActionableDarkOrderForOneUnit.md)
* [PlainDarkOrderForOneUnit (MedicationRequest)](MedicationRequest-PlainDarkOrderForOneUnit.md)
* [PlainMilkOrder (MedicationRequest)](MedicationRequest-PlainMilkOrder.md)
* [med-request-1234 (MedicationRequest)](MedicationRequest-med-request-1234.md)
* [FulfillForOneUnit (Task)](Task-FulfillForOneUnit.md)
* [FulfillPlainMilkOrder (Task)](Task-FulfillPlainMilkOrder.md)
