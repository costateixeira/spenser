# Home - Spenser - a developer's companion v1.0.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://costateixeira.github.io/spenser/ImplementationGuide/jct.fhir.spenser | *Version*:1.0.0 |
| Active as of 2025-05-01 | *Computable Name*:Spenser |

This is the complete specification for Spenser, a FHIR developer companion.

**Spenser is a chocolate dispenser, supporting a FHIR interface for requesting chocolates (as meds), as well adjusting and monitoring inventory.**

This open source specification provides everything you need to create your own Spenser:

* Hardware (3d printable + electronic components + 3D printables)
* Software (for the ESP32 chip)

**This documentation and set of artefacts are still undergoing development.**

**FHIR® and the flame icon are the registered trademark of HL7 and are used with the permission of HL7. Use of the FHIR trademark does not constitute endorsement of the contents of this product by HL7**

### Background

* Developers need chocolate. Everybody needs chocolate.
* Chocolate may be considered therapeutic - or prophylactic. Because of this, Spenser considers chocolate to be a Medication.


  Shrime, M. G., Bauer, S. R., McDonald, A. C., Chowdhury, N. H., Coltart, C. E., & Ding, E. L. (2011).
 **Flavonoid-rich cocoa consumption affects multiple cardiovascular risk factors in a meta-analysis of short-term studies.**
 **The Journal of Nutrition, 141**(11), 1982–1988.
 [https://doi.org/10.3945/jn.111.145482](https://doi.org/10.3945/jn.111.145482)

 The design and implementation of this product has been subject to unit testing - many units have been consumed to test the system's operation and effect.

